package com.codeclan.restaurantbookings.restaurantbookings;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestaurantBookingsApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestaurantBookingsApplication.class, args);
	}

}
